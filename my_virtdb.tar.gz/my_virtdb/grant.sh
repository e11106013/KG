#!/bin/bash

CONTAINER_NAME=virtuoso
ISQL_CMD="isql 1111 dba admin"

# 1. 取得所有 SPARQL_SINV_* 視圖
VIEWS=$(docker exec -i $CONTAINER_NAME $ISQL_CMD <<'EOF'
SET HEAD OFF;
SET FEEDBACK OFF;
SELECT table_name FROM DB.DBA.tables
 WHERE table_schema='DB' AND table_name LIKE 'SPARQL_SINV_%';
QUIT;
EOF
)

# 2. 逐一授權
for view in $VIEWS; do
  echo "授權 $view ..."
  docker exec -i $CONTAINER_NAME $ISQL_CMD <<EOF
GRANT SELECT ON DB.DBA.${view} TO dba;
EOF
done

echo "所有 SPARQL_SINV_* 視圖都已授予 SELECT 給 dba"
