#!/bin/bash

CONTAINER_NAME=virtuoso
TTL_DIR=/database/ttl
GRAPH_URI=http://example.org/graph

echo "Start to import RDF into Virtuoso Graph: $GRAPH_URI"

docker exec -i $CONTAINER_NAME isql 1111 dba admin <<EOF
ld_dir ('$TTL_DIR', '*.ttl', '$GRAPH_URI');
rdf_loader_run();
checkpoint;
EOF

echo "Finshed!"
